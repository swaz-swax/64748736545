package com.capg.project.bank.db;

import java.util.HashMap;

import com.capg.project.bank.bean.Customer;

public class CustomerDB 
{ HashMap<Integer, Customer> hashMap=new HashMap<Integer, Customer>();
  	
	

}
