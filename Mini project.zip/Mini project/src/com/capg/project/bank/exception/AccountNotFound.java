package com.capg.project.bank.exception;

public class AccountNotFound extends Exception {

	public AccountNotFound() {
		super();
		
	}
}
