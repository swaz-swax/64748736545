package com.sample.rers.exception;

public class OwnerDoesNotExist extends Exception {

	public OwnerDoesNotExist() {
		super();
		
	}

}
